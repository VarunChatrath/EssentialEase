import { Navigate, Route, Routes } from 'react-router-dom';
import Signup from './Signup';
import Homepage from './Homepage';
import Loginhere from './Loginhere';
import Thanks from './Thanks';
import ViewMember from './ViewMember';
import Searchuser from './Searchuser';
import Managecategory from './Managecategory';
import Managesubcat from './Managesubcat';
import ManageProd from './ManageProd';
import UpdateSubCat from './UpdateSubCat';
import UpdateProduct from './UpdateProd';
import ChangePassword from './ChangePassword';
import ShowSubCategory from './ShowSubCategory';
import Showproducts from './Showproducts';
import ShowCategory from './Showcategory';
import ProductDetails from './ProductDetails';
import ShowCart from './ShowCart';
import OrderSummary from './OrderSummary';
import Checkout from './Checkout';

const SiteRoutes=()=>
{
    
    return(
        <Routes>
            <Route path='/' element={<Navigate to="/homepage"/>}/>
            <Route path='/homepage' element={<Homepage/>}/>
            <Route path='/login' element={<Loginhere/>}/>
            <Route path='/signup' element={<Signup/>}/>
            <Route path='/thanks' element={<Thanks/>}/>
            <Route path='/viewmembers' element={<ViewMember/>}/>
            <Route path='/managecategory' element={<Managecategory/>}/>
            <Route path='/managesubcategory' element={<Managesubcat/>}/>
            <Route path='/manageprod' element={<ManageProd/>}/>
            <Route path='/searchmembers' element={<Searchuser/>}/>
            <Route path='/updatesubcategory' element={<UpdateSubCat/>}/>
            <Route path='/updateproduct' element={<UpdateProduct/>}/>
            <Route path='/changepassword' element={<ChangePassword/>}/>
            <Route path='/cart' element={<ShowCart/>}/>  
            <Route path='/subcategories' element={<ShowSubCategory/>}/>
            <Route path='/products' element={<Showproducts/>}/>
            <Route path='/showcategory' element={<ShowCategory/>}/>
            <Route path='/details' element={<ProductDetails/>}/>
            <Route path='/ordersummary' element={<OrderSummary/>}/>   
            <Route path='/checkout' element={<Checkout/>}/>   
            <Route path='/*' element={<h1>Page Not Found</h1>}/>
        </Routes>
    )
}
export default SiteRoutes;