import React from 'react'

export default function Homepage() {
  return (
    <>
    <h1>Welcome to Homepage</h1>
    </>
  )
}
