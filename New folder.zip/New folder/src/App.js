import { ToastContainer } from 'react-toastify'
import Footer from './Components/Footer'
import Header from './Components/Header'
import SiteRoutes from './Components/SiteRoutes'
import 'react-toastify/dist/ReactToastify.css';
import { useEffect,useState } from "react";
import UserContext from "./UserContext";


export default function App() {
  const [user,setUser] = useState(null);
  useEffect(()=>
  {
    if(sessionStorage.getItem("userinfo")!==null)
    {
      setUser(JSON.parse(sessionStorage.getItem("userinfo")));
    }
  },[])
  return (
    <>
    <ToastContainer theme="colored"/>
    <UserContext.Provider value={{ user, setUser}}>
    <Header/>
    <SiteRoutes/>
    <Footer/>
    </UserContext.Provider>
    </>
  )
}

